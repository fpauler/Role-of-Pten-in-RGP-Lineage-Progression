#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.192803
#SBATCH --output=s.192803.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803/alignment.192803.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.192803. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/192803_S145_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803/STAR.192803.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803/STAR.192803.log

cp -R /localhome/fpauler/STAR.192803.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192803/.
rm /localhome/fpauler/STAR.192803.* -r 
rm /localhome/fpauler/PIPE*192803
