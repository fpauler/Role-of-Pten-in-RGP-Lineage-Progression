#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.192806
#SBATCH --output=s.192806.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806/alignment.192806.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.192806. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/192806_S142_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806/STAR.192806.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806/STAR.192806.log

cp -R /localhome/fpauler/STAR.192806.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192806/.
rm /localhome/fpauler/STAR.192806.* -r 
rm /localhome/fpauler/PIPE*192806
