#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.192788
#SBATCH --output=s.192788.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788/alignment.192788.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.192788. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/192788_S160_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788/STAR.192788.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788/STAR.192788.log

cp -R /localhome/fpauler/STAR.192788.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.192788/.
rm /localhome/fpauler/STAR.192788.* -r 
rm /localhome/fpauler/PIPE*192788
